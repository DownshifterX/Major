"""Extracts plain text from uploaded documents.

Kept intentionally simple for the PoC: .txt/.md are read directly, .pdf is
parsed with pypdf. Anything else is rejected with a clear error rather than
silently mishandled.
"""
import io
from pypdf import PdfReader


class UnsupportedFileType(Exception):
    pass


def extract_text(filename: str, raw_bytes: bytes) -> str:
    lower = filename.lower()
    if lower.endswith(".pdf"):
        return _extract_pdf(raw_bytes)
    if lower.endswith(".txt") or lower.endswith(".md"):
        return raw_bytes.decode("utf-8", errors="replace")
    raise UnsupportedFileType(
        f"Unsupported file type for '{filename}'. Supported: .pdf, .txt, .md"
    )


def _extract_pdf(raw_bytes: bytes) -> str:
    reader = PdfReader(io.BytesIO(raw_bytes))
    pages = []
    for i, page in enumerate(reader.pages):
        text = page.extract_text() or ""
        pages.append(f"\n\n[[PAGE {i + 1}]]\n{text}")
    return "".join(pages)
