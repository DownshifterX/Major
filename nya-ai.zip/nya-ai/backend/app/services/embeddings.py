"""Embedding provider abstraction.

EmbeddingProvider.embed(texts) -> list[list[float]]

Default provider (`local`) uses a deterministic hashing-based TF-style
vectorizer (scikit-learn's HashingVectorizer). It needs no network call and
no downloaded model, which keeps the PoC fully self-contained, but it is
still a genuine text vectorization (not a random/fake vector) — near-duplicate
and topically-similar text produce cosine-similar vectors. This is clearly a
lexical/statistical embedding, not a deep semantic embedding.

Swap in a real semantic embedding API (OpenAI, Voyage, Cohere, an in-house
model, etc.) by implementing another EmbeddingProvider and changing
EMBEDDING_PROVIDER in the environment — nothing else in the pipeline needs to
change because retrieval only depends on this interface.
"""
import os
from abc import ABC, abstractmethod
from typing import List

import numpy as np
from sklearn.feature_extraction.text import HashingVectorizer

EMBEDDING_DIM = int(os.getenv("EMBEDDING_DIM", "512"))


class EmbeddingProvider(ABC):
    @abstractmethod
    def embed(self, texts: List[str]) -> List[List[float]]:
        ...


class LocalHashingEmbeddingProvider(EmbeddingProvider):
    """Deterministic, dependency-free embedding for offline demo use."""

    def __init__(self, n_features: int = EMBEDDING_DIM):
        self._vectorizer = HashingVectorizer(
            n_features=n_features,
            alternate_sign=False,
            norm="l2",
            ngram_range=(1, 2),
            stop_words="english",
        )

    def embed(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        matrix = self._vectorizer.transform(texts)
        return matrix.toarray().astype(float).tolist()


class OpenAIEmbeddingProvider(EmbeddingProvider):
    """Placeholder for a real semantic embedding API.

    Not wired to a live network call in this PoC sandbox — implement the
    HTTP call to your embedding provider of choice here when you have API
    access, keeping the same embed() signature.
    """

    def __init__(self):
        raise NotImplementedError(
            "OpenAIEmbeddingProvider is a stub. Implement the API call and "
            "set EMBEDDING_PROVIDER=openai once you have network + API key access."
        )

    def embed(self, texts: List[str]) -> List[List[float]]:
        raise NotImplementedError


_provider_singleton: EmbeddingProvider | None = None


def get_embedding_provider() -> EmbeddingProvider:
    global _provider_singleton
    if _provider_singleton is None:
        name = os.getenv("EMBEDDING_PROVIDER", "local")
        if name == "local":
            _provider_singleton = LocalHashingEmbeddingProvider()
        elif name == "openai":
            _provider_singleton = OpenAIEmbeddingProvider()
        else:
            raise ValueError(f"Unknown EMBEDDING_PROVIDER '{name}'")
    return _provider_singleton


def cosine_similarity(a: List[float], b: List[float]) -> float:
    va, vb = np.array(a), np.array(b)
    na, nb = np.linalg.norm(va), np.linalg.norm(vb)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(va, vb) / (na * nb))
