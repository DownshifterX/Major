from typing import Optional, List, Dict, Any
from pydantic import BaseModel


class PartyIn(BaseModel):
    role: str
    name: str


class CaseCreate(BaseModel):
    title: str
    case_type: Optional[str] = None
    parties: Optional[List[PartyIn]] = []
    facts: Optional[str] = ""
    charges_issues: Optional[str] = ""
    arguments_text: Optional[str] = ""
    evidence_text: Optional[str] = ""
    timeline: Optional[List[Dict[str, Any]]] = []


class CaseUpdate(BaseModel):
    title: Optional[str] = None
    case_type: Optional[str] = None
    parties: Optional[List[PartyIn]] = None
    facts: Optional[str] = None
    charges_issues: Optional[str] = None
    arguments_text: Optional[str] = None
    evidence_text: Optional[str] = None
    timeline: Optional[List[Dict[str, Any]]] = None


class CaseOut(BaseModel):
    id: str
    title: str
    case_type: Optional[str]
    parties: Optional[List[Dict[str, Any]]]
    facts: str
    charges_issues: str
    arguments_text: str
    evidence_text: str
    timeline: Optional[List[Dict[str, Any]]]
    status: str

    class Config:
        from_attributes = True


class DocumentOut(BaseModel):
    id: str
    filename: str
    doc_type: str
    source: str
    num_chunks: int

    class Config:
        from_attributes = True


class CompareRequest(BaseModel):
    historical_case_id: str
